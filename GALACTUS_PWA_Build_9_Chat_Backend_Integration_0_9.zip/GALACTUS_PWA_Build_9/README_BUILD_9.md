# GALACTUS PWA Build 9 (0.9) — Chat & Backend Integration

## What this build does
- Loads `runtime.js` before `app.js` so the chat and Model Manager can use the backend adapter.
- Sends chat history to the configured backend's `POST /api/chat` endpoint.
- Requires a successful `GET /api/health` response and `model_ready: true` before describing the backend as configured.
- Rejects backend URLs containing credentials or query parameters; no API keys belong in public frontend files.
- Bumps the service-worker cache to `galactus-pwa-build-0.9`.
- Includes a Python backend adapter and automated API-contract tests.

## Important limitation
This is integration code, not a hosted AI service. GitHub Pages serves only the static frontend. To get real AI replies, deploy `backend.py` to a trusted HTTPS-capable server and configure it with a compatible OpenAI-style model endpoint. The backend defaults to binding `127.0.0.1`; do not expose it directly to the internet without proper hosting, authentication/rate limits, and review. Set `GALACTUS_ALLOWED_ORIGIN` to `https://shyamalakonaipalli-hub.github.io` for this GitHub Pages site. Configure `GALACTUS_UPSTREAM_URL`, and if needed `GALACTUS_UPSTREAM_API_KEY`, as server-side environment secrets. Never place API keys in `docs/*.js`.

The automated Build 9 tests use mocked model replies. They verify API contract and error handling, not live inference, model accuracy, or deployment on the user's phone.

## Phone-only GitHub Pages update
1. Upload/replace the files in this archive's `docs/` folder in the repository's existing `docs/` folder.
2. Do not upload `backend.py` as a public website file; it must be deployed separately as a backend service.
3. Keep the existing `.github/workflows/universal.yml`; do not create a per-build workflow.
4. Commit the changes to `main`, then check the existing GitHub Actions workflow.
5. After Pages updates, reopen GALACTUS PWA, go to Model Manager, and enter only the HTTPS base URL of a backend you control. Tap Save URL and Test connection. Do not enter API keys in the PWA.

Until a backend is actually deployed and a model is configured, the AI chat will report a connection/configuration error instead of fabricating a response.
