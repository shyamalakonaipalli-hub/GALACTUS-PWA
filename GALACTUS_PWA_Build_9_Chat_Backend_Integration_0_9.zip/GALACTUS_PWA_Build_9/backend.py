#!/usr/bin/env python3
"""GALACTUS PWA Build 4 backend with an OpenAI-compatible inference adapter.

Local development only. A separate model server (for example llama.cpp's
OpenAI-compatible server) must be started and loaded with a compatible model.
"""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
import json, os, socket

HOST = os.environ.get("GALACTUS_HOST", "127.0.0.1")
PORT = int(os.environ.get("GALACTUS_PORT", "8787"))
ALLOWED_ORIGIN = os.environ.get("GALACTUS_ALLOWED_ORIGIN", "http://localhost:8080").rstrip("/")
UPSTREAM_URL = os.environ.get("GALACTUS_UPSTREAM_URL", "").strip().rstrip("/")
UPSTREAM_API_KEY = os.environ.get("GALACTUS_UPSTREAM_API_KEY", "").strip()
UPSTREAM_MODEL = os.environ.get("GALACTUS_UPSTREAM_MODEL", "local-model").strip() or "local-model"
ALLOW_REMOTE = os.environ.get("GALACTUS_ALLOW_REMOTE_UPSTREAM", "0") == "1"
UPSTREAM_TIMEOUT = min(max(int(os.environ.get("GALACTUS_UPSTREAM_TIMEOUT", "90")), 3), 180)
MAX_BODY, MAX_MESSAGES, MAX_CONTENT_CHARS = 64 * 1024, 40, 12000
MODES = {"auto", "fast", "reasoning", "creative", "complex"}


def upstream_configuration_error():
    if not UPSTREAM_URL:
        return "GALACTUS_UPSTREAM_URL is not configured. Start a compatible model server and configure its chat-completions endpoint."
    parsed = urlparse(UPSTREAM_URL)
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        return "GALACTUS_UPSTREAM_URL must be a valid HTTP(S) URL."
    host = parsed.hostname.lower()
    loopback = host in ("localhost", "127.0.0.1", "::1")
    if not loopback and not (ALLOW_REMOTE and parsed.scheme == "https"):
        return "Remote upstreams are disabled by default. Use localhost, or explicitly allow a remote HTTPS endpoint."
    if parsed.username or parsed.password:
        return "Do not embed credentials in the upstream URL; use the server-side API-key environment variable."
    return None


def generate_reply(messages, mode):
    config_error = upstream_configuration_error()
    if config_error:
        raise RuntimeError(config_error)
    # Map broad modes to conservative sampling settings; model behavior depends on its server.
    temperature = {"fast": 0.2, "reasoning": 0.2, "creative": 0.85, "complex": 0.3, "auto": 0.4}[mode]
    payload = {"model": UPSTREAM_MODEL, "messages": messages, "temperature": temperature, "stream": False}
    req_headers = {"Content-Type": "application/json", "Accept": "application/json"}
    if UPSTREAM_API_KEY:
        req_headers["Authorization"] = "Bearer " + UPSTREAM_API_KEY
    request = Request(UPSTREAM_URL, data=json.dumps(payload).encode("utf-8"), headers=req_headers, method="POST")
    try:
        with urlopen(request, timeout=UPSTREAM_TIMEOUT) as response:
            if response.status < 200 or response.status >= 300:
                raise RuntimeError(f"Model server returned HTTP {response.status}.")
            raw = response.read(2 * 1024 * 1024 + 1)
    except HTTPError as exc:
        # Do not relay upstream response bodies; they might contain private/debug data.
        raise RuntimeError(f"Model server returned HTTP {exc.code}.") from None
    except (URLError, socket.timeout, TimeoutError) as exc:
        reason = getattr(exc, "reason", None)
        if isinstance(reason, (socket.timeout, TimeoutError)) or isinstance(exc, (socket.timeout, TimeoutError)):
            raise RuntimeError("Model server request timed out.") from None
        raise RuntimeError("Could not connect to the configured model server. Check that it is running and reachable.") from None
    if len(raw) > 2 * 1024 * 1024:
        raise RuntimeError("Model server response exceeded the 2 MiB safety limit.")
    try:
        data = json.loads(raw.decode("utf-8"))
        reply = data["choices"][0]["message"]["content"]
    except (UnicodeDecodeError, json.JSONDecodeError, KeyError, IndexError, TypeError):
        raise RuntimeError("Model server returned an unexpected response. Expected OpenAI-compatible choices[0].message.content.") from None
    if not isinstance(reply, str) or not reply.strip():
        raise RuntimeError("Model server returned an empty or non-text response.")
    return reply.strip()


class Handler(BaseHTTPRequestHandler):
    server_version = "GalactusPWADevAPI/0.4"
    def log_message(self, fmt, *args):
        # No prompt/request body is logged.
        super().log_message(fmt, *args)
    def _headers(self, status=200, content_type="application/json; charset=utf-8"):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "default-src 'none'; frame-ancestors 'none'")
        origin = self.headers.get("Origin")
        if origin and origin == ALLOWED_ORIGIN:
            self.send_header("Access-Control-Allow-Origin", ALLOWED_ORIGIN)
            self.send_header("Vary", "Origin")
        self.end_headers()
    def _json(self, status, obj):
        self._headers(status)
        self.wfile.write(json.dumps(obj, ensure_ascii=False).encode("utf-8"))
    def do_OPTIONS(self):
        origin = self.headers.get("Origin", "")
        if origin and origin != ALLOWED_ORIGIN:
            self._json(403, {"error": "origin_not_allowed"}); return
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", ALLOWED_ORIGIN)
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Max-Age", "600")
        self.send_header("Vary", "Origin")
        self.end_headers()
    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/health":
            config_error = upstream_configuration_error()
            self._json(200, {"ok": True, "name": "GALACTUS PWA development backend", "version": "0.4", "model_ready": config_error is None, "model_adapter": "openai-compatible" if config_error is None else None, "model_note": "Configured endpoint only; actual model availability is confirmed on a chat request." if config_error is None else config_error})
        elif path == "/": self._json(200, {"service": "GALACTUS PWA API", "health": "/api/health", "chat": "/api/chat", "version": "0.4"})
        else: self._json(404, {"error": "not_found"})
    def do_POST(self):
        if urlparse(self.path).path != "/api/chat": self._json(404, {"error": "not_found"}); return
        if self.headers.get("Content-Type", "").split(";", 1)[0].strip().lower() != "application/json": self._json(415, {"error": "content_type_must_be_application_json"}); return
        try: length = int(self.headers.get("Content-Length", "-1"))
        except ValueError: length = -1
        if length < 0 or length > MAX_BODY: self._json(413, {"error": "invalid_or_too_large_body", "max_bytes": MAX_BODY}); return
        try: payload = json.loads(self.rfile.read(length).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError): self._json(400, {"error": "invalid_json"}); return
        messages = payload.get("messages") if isinstance(payload, dict) else None
        mode = payload.get("mode", "auto") if isinstance(payload, dict) else "auto"
        if not isinstance(messages, list) or not messages or len(messages) > MAX_MESSAGES: self._json(400, {"error": "messages_must_be_a_list_of_1_to_40_items"}); return
        if mode not in MODES: self._json(400, {"error": "unsupported_mode"}); return
        for item in messages:
            if not isinstance(item, dict) or item.get("role") not in ("user", "assistant", "system") or not isinstance(item.get("content"), str): self._json(400, {"error": "each_message_needs_valid_role_and_string_content"}); return
            if len(item["content"]) > MAX_CONTENT_CHARS: self._json(413, {"error": "message_too_long", "max_chars": MAX_CONTENT_CHARS}); return
        try:
            reply = generate_reply(messages, mode)
            self._json(200, {"reply": reply, "model": UPSTREAM_MODEL, "adapter": "openai-compatible"})
        except RuntimeError as exc:
            self._json(503, {"error": "model_unavailable", "message": str(exc)})
    def do_PUT(self): self._json(405, {"error": "method_not_allowed"})

if __name__ == "__main__":
    print(f"GALACTUS PWA dev API listening on http://{HOST}:{PORT}")
    print(f"Allowed browser origin: {ALLOWED_ORIGIN}")
    print("Inference adapter: OpenAI-compatible chat-completions endpoint")
    print("Development only. Keep bound to localhost; do not expose publicly.")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
