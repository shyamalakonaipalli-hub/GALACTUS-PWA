"""Build 9 API and frontend integration tests. Inference is mocked; no model is loaded."""
import json
import sys
import threading
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import backend


class Build9BackendTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), backend.Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)

    def get_json(self, path):
        with urlopen(self.base + path, timeout=3) as response:
            return response.status, json.loads(response.read().decode())

    def post_json(self, path, payload):
        request = Request(self.base + path, data=json.dumps(payload).encode(),
                          headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urlopen(request, timeout=3) as response:
                return response.status, json.loads(response.read().decode())
        except HTTPError as error:
            return error.code, json.loads(error.read().decode())

    def test_health_endpoint_is_json_and_reports_unconfigured_model(self):
        with patch.object(backend, "upstream_configuration_error", return_value="not configured"):
            status, data = self.get_json("/api/health")
        self.assertEqual(status, 200)
        self.assertTrue(data["ok"])
        self.assertFalse(data["model_ready"])

    def test_chat_returns_mocked_reply_through_api_contract(self):
        payload = {"messages": [{"role": "user", "content": "Hello"}], "mode": "auto"}
        with patch.object(backend, "generate_reply", return_value="MOCKED_TEST_REPLY"):
            status, data = self.post_json("/api/chat", payload)
        self.assertEqual(status, 200)
        self.assertEqual(data["reply"], "MOCKED_TEST_REPLY")
        self.assertEqual(data["adapter"], "openai-compatible")

    def test_chat_rejects_invalid_message_payload(self):
        status, data = self.post_json("/api/chat", {"messages": "not a list"})
        self.assertEqual(status, 400)
        self.assertIn("error", data)

    def test_unknown_route_is_404(self):
        try:
            self.get_json("/missing")
        except HTTPError as error:
            self.assertEqual(error.code, 404)
        else:
            self.fail("Expected HTTP 404")


class Build9FrontendTests(unittest.TestCase):
    def test_runtime_loaded_before_app(self):
        html = (ROOT / "docs" / "index.html").read_text()
        self.assertLess(html.index('src="runtime.js"'), html.index('src="app.js"'))

    def test_runtime_checks_model_ready_and_blocks_url_credentials(self):
        js = (ROOT / "docs" / "runtime.js").read_text()
        self.assertIn("data.model_ready !== true", js)
        self.assertIn("url.username || url.password", js)

    def test_pwa_source_and_deployed_files_match(self):
        for name in ("index.html", "app.js", "styles.css", "sw.js", "runtime.js",
                     "manifest.webmanifest", "icon.svg", "offline.html"):
            self.assertEqual((ROOT / "pwa" / name).read_bytes(), (ROOT / "docs" / name).read_bytes(), name)


if __name__ == "__main__":
    unittest.main(verbosity=2)
