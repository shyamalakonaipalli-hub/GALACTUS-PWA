#!/usr/bin/env python3
"""Probe an OpenAI-compatible model server without sending private chat history."""
import argparse
import json
import sys
import urllib.error
import urllib.request
from urllib.parse import urlparse


def request_json(url, timeout, payload=None, api_key=None):
    headers = {"Accept": "application/json"}
    data = None
    method = "GET"
    if payload is not None:
        method = "POST"
        headers["Content-Type"] = "application/json"
        data = json.dumps(payload).encode("utf-8")
    if api_key:
        headers["Authorization"] = "Bearer " + api_key
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            raw = response.read(1024 * 1024 + 1)
            if len(raw) > 1024 * 1024:
                return response.status, None, "Response exceeded 1 MiB limit"
            try:
                return response.status, json.loads(raw.decode("utf-8")), None
            except (UnicodeDecodeError, json.JSONDecodeError):
                return response.status, None, "Response was not valid JSON"
    except urllib.error.HTTPError as exc:
        return exc.code, None, f"HTTP {exc.code}"
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        return None, None, f"Connection failed: {type(exc).__name__}"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", required=True, help="Server base URL, e.g. http://127.0.0.1:8081")
    parser.add_argument("--timeout", type=float, default=5.0)
    parser.add_argument("--api-key", default="", help="Optional token; avoid putting secrets in shell history")
    parser.add_argument("--chat-test", action="store_true", help="Send a generic test prompt; no conversation history is sent")
    parser.add_argument("--model", default="", help="Optional model ID for the chat test")
    args = parser.parse_args()
    base = args.base_url.rstrip("/")
    parsed = urlparse(base)
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        parser.error("--base-url must be a valid HTTP(S) URL")
    if parsed.scheme == "http" and parsed.hostname not in ("localhost", "127.0.0.1", "::1"):
        parser.error("Plain HTTP is allowed only for loopback addresses; use HTTPS for remote servers")
    report = {"base_url": base, "checks": [], "chat_test_requested": args.chat_test}
    status, data, err = request_json(base + "/v1/models", args.timeout, api_key=args.api_key)
    models = []
    if status and status < 300 and isinstance(data, dict) and isinstance(data.get("data"), list):
        models = [item.get("id") for item in data["data"] if isinstance(item, dict) and isinstance(item.get("id"), str)]
        report["checks"].append({"name": "models_endpoint", "ok": True, "model_ids": models})
    else:
        report["checks"].append({"name": "models_endpoint", "ok": False, "status": status, "detail": err or "Expected JSON with a data array"})
    if args.chat_test:
        chosen = args.model or (models[0] if models else "local-model")
        payload = {"model": chosen, "messages": [{"role": "user", "content": "Reply with the single word READY."}], "stream": False, "temperature": 0}
        status, data, err = request_json(base + "/v1/chat/completions", args.timeout, payload, args.api_key)
        try:
            content = data["choices"][0]["message"]["content"] if isinstance(data, dict) else None
            ok = bool(status and status < 300 and isinstance(content, str) and content.strip())
        except (KeyError, IndexError, TypeError):
            content, ok = None, False
        check = {"name": "chat_completions", "ok": ok, "status": status}
        if ok:
            check["reply_received"] = True
            check["reply_preview"] = content.strip()[:80]
        else:
            check["detail"] = err or "Expected choices[0].message.content as non-empty text"
        report["checks"].append(check)
    report["compatible"] = bool(report["checks"]) and all(c["ok"] for c in report["checks"])
    print(json.dumps(report, indent=2))
    return 0 if report["compatible"] else 1

if __name__ == "__main__":
    sys.exit(main())
