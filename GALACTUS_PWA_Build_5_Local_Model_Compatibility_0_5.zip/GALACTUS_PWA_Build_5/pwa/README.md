# GALACTUS PWA — Build 2: Runtime Foundation 0.2

This is a standalone PWA project, separate from GALACTUS PERSONAL AI MARK-2, GALACTUS-14B, GALACTUS-E, and the cloud/Colab experiments.

## Build 2 changes
- Added `runtime.js`, a small backend adapter with a health-check and chat API contract.
- Added Model Manager controls to save a backend base URL and test `GET /api/health`.
- Chat now calls `POST /api/chat` only when a backend URL has been configured. If the request fails, it displays the failure rather than inventing an AI answer.
- Added request timeout handling, response validation, and service-worker cache version update.
- The browser stores only the backend URL. It does not ask for or store API keys.

## Backend contract
Implement these endpoints on a server you control:

`GET /api/health` should return JSON such as:
```json
{ "ok": true, "name": "GALACTUS AI backend" }
```

`POST /api/chat` receives:
```json
{ "messages": [{ "role": "user", "content": "Hello" }], "mode": "auto" }
```

It should return JSON such as:
```json
{ "reply": "Hello!" }
```

The example reply above documents the shape only; no backend is included in this ZIP, so it will not produce an answer until you connect a real server. Configure CORS narrowly for your deployed website, require HTTPS, authenticate requests as appropriate, rate-limit the API, and keep provider API keys only on the server. Never put secrets in public JavaScript.

## Run and install
Serve this folder from `localhost` for development or deploy it to an HTTPS host. Open the site in a compatible Android browser and choose **Install app** or **Add to Home screen** when available. A service worker requires HTTPS or localhost.

## Local model reality check
- This build does not run a model by itself.
- A GGUF file, including `Qwen3-4B-Q4_K_M.gguf`, cannot simply be selected by a webpage and expected to execute. Browser inference requires a compatible browser runtime and model format, or a local companion service.
- WebGPU support, browser memory limits, device heat, and model conversion/runtime compatibility must be tested on the target phone before committing to a local inference approach. The 4B model is large for a mobile browser and may fail due to memory pressure.
- No claim is made that GALACTUS-14B is browser-compatible; it needs a separate runtime compatibility test.
- Voice recognition may depend on browser support and may use an online service. Image selection is not image understanding.

## Test checklist
1. Open Model Manager.
2. Save your backend base URL (without `/api/health`).
3. Tap **Test connection** and verify a successful health response.
4. Send a short chat message and confirm the real backend returns `{ "reply": "..." }`.
5. Test failed URL, offline state, timeout, and non-JSON responses.
6. Test on the actual Android device before considering this build production-ready.

## Status
Build 2 establishes the frontend-to-backend contract and failure handling. A real AI backend, local model runtime, streaming, secure login, encrypted memory, vision, image generation, voice pipeline, tools/agents, and wake-word support remain future work.
