# GALACTUS PWA — Build 5 (0.5)

Build 5 adds a small diagnostic tool for probing an already-running OpenAI-compatible model server. It checks `/v1/models` and optionally sends a generic test request to `/v1/chat/completions`.

## Run tests

```sh
python3 -m unittest -v test_build5.py
```

## Probe a model server

```sh
python3 tools/check_model_server.py --base-url http://127.0.0.1:8081
python3 tools/check_model_server.py --base-url http://127.0.0.1:8081 --chat-test
```

See `MODEL_COMPATIBILITY.md` for limitations, security notes, and the checklist before declaring a model supported.

## Honest status

The tests use a mock server and verify the diagnostic behavior only. No real inference runtime or model weights are bundled. No claim is made that Qwen3-4B, GALACTUS-14B, or Android-local inference works yet.
