import json
import subprocess
import sys
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

SCRIPT = Path(__file__).parent / "tools" / "check_model_server.py"

class MockHandler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass
    def do_GET(self):
        body = {"data": [{"id": "mock-local-model"}]} if self.path == "/v1/models" else {"error": "not found"}
        status = 200 if self.path == "/v1/models" else 404
        self.send_response(status); self.send_header("Content-Type", "application/json"); self.end_headers()
        self.wfile.write(json.dumps(body).encode())
    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0")); json.loads(self.rfile.read(length))
        body = {"choices": [{"message": {"content": "READY"}}]}
        self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers()
        self.wfile.write(json.dumps(body).encode())

class Build5Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = HTTPServer(("127.0.0.1", 0), MockHandler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True); cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_port}"
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close(); cls.thread.join(timeout=2)
    def test_models_endpoint_probe(self):
        result = subprocess.run([sys.executable, str(SCRIPT), "--base-url", self.base], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        data = json.loads(result.stdout)
        self.assertTrue(data["compatible"])
        self.assertEqual(data["checks"][0]["model_ids"], ["mock-local-model"])
    def test_chat_completions_probe(self):
        result = subprocess.run([sys.executable, str(SCRIPT), "--base-url", self.base, "--chat-test"], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        data = json.loads(result.stdout)
        self.assertTrue(data["compatible"])
        self.assertTrue(data["checks"][1]["reply_received"])
    def test_rejects_remote_plain_http(self):
        result = subprocess.run([sys.executable, str(SCRIPT), "--base-url", "http://example.com:8081"], capture_output=True, text=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("use HTTPS", result.stderr)

if __name__ == "__main__": unittest.main()
