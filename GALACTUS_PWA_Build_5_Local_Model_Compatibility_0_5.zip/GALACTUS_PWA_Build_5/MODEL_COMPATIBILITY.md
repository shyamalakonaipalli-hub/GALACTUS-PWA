# GALACTUS PWA — Build 5: Local Model Server Compatibility

## What this build does

Build 5 adds a diagnostic tool that checks whether an **already running** OpenAI-compatible inference server exposes `/v1/models` and, optionally, `/v1/chat/completions`. The diagnostic uses a generic one-line test prompt and does not send your chat history. Its automated tests use a mock server; they do **not** prove that a real model server or Qwen model works.

## Important distinction: PWA vs. model runtime

A PWA is a web application. It does not make GGUF files executable by itself. A compatible inference runtime must load the model and expose an API, or a browser-native runtime must be integrated and tested separately. This build does not include model weights, install llama.cpp, or start an inference server.

## Test an existing server

With Python 3 installed, run this from the extracted Build 5 folder:

```sh
python3 tools/check_model_server.py --base-url http://127.0.0.1:8081
```

To also make a small generic chat request:

```sh
python3 tools/check_model_server.py --base-url http://127.0.0.1:8081 --chat-test
```

If the server requires a token, pass `--api-key` only in a trusted local environment. Command-line secrets can appear in shell history/process listings; environment variables or a protected secret manager are preferable. Do not place tokens in PWA JavaScript or a public repository.

For a remote server, use HTTPS. The diagnostic rejects non-loopback plain HTTP by design.

## Model compatibility checklist

Before calling Qwen3-4B or GALACTUS-14B supported, verify all of the following with the exact runtime version and model file:

1. The runtime can parse the GGUF file and its quantization/architecture.
2. The model's chat template and special tokens are supported correctly.
3. `/v1/models` reports the loaded model and `/v1/chat/completions` returns valid text.
4. A multi-turn conversation works without role/template corruption.
5. Memory use, load time, first-token latency, and generation speed are measured on the target device.
6. Cancellation, long prompts, malformed requests, and server restarts fail safely.

A successful API probe only proves the endpoint contract, not model quality or suitability for a 6 GB Android phone.

## Local phone vs. another computer

- **Phone-local inference:** requires an Android/browser-compatible runtime and enough free RAM. It has not been implemented or validated here.
- **Server on another device:** the PWA calls that server over a network. The server device performs inference; the phone does not. Secure HTTPS, authentication, and network configuration are required before remote use.

## Security

The Build 4 backend is a development server with no user authentication or production TLS. Keep it bound to loopback while testing. Do not expose it directly to the public internet. A public deployment needs authenticated access, HTTPS, origin controls, rate limiting, secret management, and privacy-conscious logging.
