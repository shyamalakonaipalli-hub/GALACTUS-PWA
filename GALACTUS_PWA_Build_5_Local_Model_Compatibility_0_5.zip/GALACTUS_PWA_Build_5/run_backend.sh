#!/bin/sh
set -eu
cd "$(dirname "$0")"
export GALACTUS_HOST="${GALACTUS_HOST:-127.0.0.1}"
export GALACTUS_PORT="${GALACTUS_PORT:-8787}"
export GALACTUS_ALLOWED_ORIGIN="${GALACTUS_ALLOWED_ORIGIN:-http://localhost:8080}"
exec python3 backend.py
