"""Build 10 tests: live-backend probe validation; no external backend is called."""
import importlib.util
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("verify_live_backend", ROOT / "tools" / "verify_live_backend.py")
probe = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(probe)


class Build10ValidationTests(unittest.TestCase):
    def test_requires_url(self):
        with self.assertRaisesRegex(ValueError, "not set"):
            probe.validate_base_url("")

    def test_requires_https(self):
        with self.assertRaisesRegex(ValueError, "HTTPS"):
            probe.validate_base_url("http://example.com")

    def test_rejects_embedded_credentials(self):
        with self.assertRaisesRegex(ValueError, "credentials"):
            probe.validate_base_url("https://user:secret@example.com")

    def test_rejects_query(self):
        with self.assertRaisesRegex(ValueError, "query parameters"):
            probe.validate_base_url("https://example.com?token=secret")

    def test_rejects_endpoint_path(self):
        with self.assertRaisesRegex(ValueError, "base URL"):
            probe.validate_base_url("https://example.com/api/health")

    def test_normalizes_base_url(self):
        self.assertEqual(probe.validate_base_url(" https://example.com/ "), "https://example.com")


if __name__ == "__main__":
    unittest.main(verbosity=2)
