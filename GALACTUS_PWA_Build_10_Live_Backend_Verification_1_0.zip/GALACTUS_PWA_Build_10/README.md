GALACTUS PWA Build 10 (1.0): live backend verification kit. Read README_BUILD_10.md before running the optional live probe.
