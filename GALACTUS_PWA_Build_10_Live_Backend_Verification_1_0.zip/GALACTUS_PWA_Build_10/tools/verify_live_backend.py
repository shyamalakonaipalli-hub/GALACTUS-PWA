#!/usr/bin/env python3
"""Optional live GALACTUS backend smoke test. Reads settings only from environment.

Required: GALACTUS_TEST_BACKEND_URL (HTTPS base URL)
Optional: GALACTUS_TEST_API_TOKEN (Bearer token configured on the backend)
The script never prints the token, request headers, prompt, or model reply.
"""
from __future__ import annotations
import json
import os
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen


def validate_base_url(value: str) -> str:
    value = (value or "").strip().rstrip("/")
    if not value:
        raise ValueError("GALACTUS_TEST_BACKEND_URL is not set")
    parsed = urlparse(value)
    if parsed.scheme != "https" or not parsed.hostname:
        raise ValueError("Backend URL must be an HTTPS base URL")
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError("Backend URL must not contain credentials, query parameters, or a fragment")
    if parsed.path not in ("", "/"):
        raise ValueError("Provide the backend base URL, not an API endpoint path")
    return value


def request_json(base: str, path: str, payload: dict | None = None, token: str = "", timeout: int = 20) -> dict:
    headers = {"Accept": "application/json"}
    data = None
    method = "GET"
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
        method = "POST"
    if token:
        headers["Authorization"] = "Bearer " + token
    req = Request(base + path, data=data, headers=headers, method=method)
    try:
        with urlopen(req, timeout=timeout) as response:
            raw = response.read(1024 * 1024 + 1)
            if len(raw) > 1024 * 1024:
                raise RuntimeError("Backend response exceeded 1 MiB")
            try:
                result = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                raise RuntimeError("Backend returned invalid JSON") from None
            if not isinstance(result, dict):
                raise RuntimeError("Backend JSON response must be an object")
            return result
    except HTTPError as exc:
        raise RuntimeError(f"Backend returned HTTP {exc.code} at {path}") from None
    except URLError as exc:
        raise RuntimeError(f"Could not connect to backend at {path}; check host, TLS, and availability") from None


def run() -> int:
    try:
        base = validate_base_url(os.environ.get("GALACTUS_TEST_BACKEND_URL", ""))
        token = os.environ.get("GALACTUS_TEST_API_TOKEN", "").strip()
        started = time.monotonic()
        health = request_json(base, "/api/health", token=token)
        if health.get("ok") is not True:
            raise RuntimeError("Health endpoint did not return ok=true")
        if health.get("model_ready") is not True:
            note = health.get("model_note")
            raise RuntimeError("Backend is reachable but model_ready is not true" + (f": {note}" if isinstance(note, str) and note else ""))
        print("PASS: HTTPS health endpoint reachable; model_ready=true")
        chat = request_json(base, "/api/chat", {
            "messages": [{"role": "user", "content": "For this connectivity test, reply with a short greeting."}],
            "mode": "fast",
        }, token=token, timeout=100)
        reply = chat.get("reply")
        if not isinstance(reply, str) or not reply.strip():
            raise RuntimeError("Chat endpoint did not return a non-empty string field named reply")
        elapsed = time.monotonic() - started
        print(f"PASS: chat endpoint returned non-empty text ({len(reply.strip())} characters)")
        print(f"PASS: total health + chat elapsed time {elapsed:.2f}s")
        print("LIMIT: endpoint responses alone cannot prove which model generated the text; verify backend logs/configuration separately.")
        return 0
    except Exception as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(run())
