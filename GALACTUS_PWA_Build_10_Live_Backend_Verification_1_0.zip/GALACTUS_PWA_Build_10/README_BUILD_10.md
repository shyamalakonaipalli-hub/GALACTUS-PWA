# GALACTUS PWA Build 10 (1.0) — Live Backend Verification Kit

## Purpose
Build 10 provides an optional smoke-test tool for a backend you have deployed and control. It checks an HTTPS `/api/health` endpoint and then sends a generic request to `/api/chat`. It does not host a backend, install a model, or make GitHub Pages run AI inference.

## Included
- `tools/verify_live_backend.py`: environment-configured HTTPS backend probe.
- `test_build10.py`: six offline unit tests for URL validation. These do not call a live model.
- This guide and build status.

## Safe use
The live probe reads `GALACTUS_TEST_BACKEND_URL` and optional `GALACTUS_TEST_API_TOKEN` from environment variables. Never commit a real token or provider API key to the repository or put it in a public JavaScript file. If your backend requires a bearer token, configure a dedicated low-privilege client token on the server and provide it only as a protected environment secret when running the probe. Do not deploy the Build 9 development server directly to the public internet without reviewing authentication, rate limits, resource limits, logging, and hosting configuration.

## Run from a trusted runner
```sh
python tools/verify_live_backend.py
```
Set these environment variables in the runner environment before executing:
- `GALACTUS_TEST_BACKEND_URL`: HTTPS origin/base URL only, such as `https://your-backend.example` (no path, credentials, query, or fragment).
- `GALACTUS_TEST_API_TOKEN`: optional bearer token if your backend requires one.

If the URL is absent, the live probe fails clearly. Do not make the default universal workflow fail merely because a live backend is not deployed yet. When you are ready, configure a protected GitHub Actions secret and explicitly add a step to run this probe. Never print the token in logs.

## What a successful live probe means
- `/api/health` responded with `ok: true` and `model_ready: true`.
- `/api/chat` returned a non-empty text field.
- A combined elapsed time was measured.

It does **not** independently prove model identity, answer quality, or that a real model rather than a mock generated the reply. Confirm backend configuration and server-side model logs separately. This package does not perform a real live test unless you provide a deployed endpoint and run it.

## Phone-only repository workflow
Upload this ZIP to the root of your existing `GALACTUS-PWA` repository, commit to `main`, then check the existing `GALACTUS PWA - Universal Verification` workflow. Keep the existing `universal.yml`; no new workflow is needed for these offline tests. The tool is verification support, not a new frontend deployment, so you do not need to replace files under `docs/` for Build 10.
